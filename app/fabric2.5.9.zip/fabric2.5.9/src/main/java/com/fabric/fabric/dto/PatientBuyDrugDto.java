package com.fabric.fabric.dto;

import lombok.Data;

@Data
public class PatientBuyDrugDto {
    private String patientName;
    private String hospitalName;
    private String drugName;
}
