package com.fabric.fabric.dto;

import lombok.Data;

@Data
public class CreateParams {
    private String name;
    private String contact;
}
