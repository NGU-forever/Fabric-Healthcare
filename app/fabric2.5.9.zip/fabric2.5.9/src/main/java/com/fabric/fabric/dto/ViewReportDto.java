package com.fabric.fabric.dto;

import lombok.Data;

@Data
public class ViewReportDto {
    private String patientName;
    private String hospitalName;
    private String reportID;
}
