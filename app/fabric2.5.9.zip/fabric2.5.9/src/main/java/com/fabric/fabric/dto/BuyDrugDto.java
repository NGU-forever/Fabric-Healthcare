package com.fabric.fabric.dto;

import lombok.Data;

@Data
public class BuyDrugDto {
    private String hospitalName;
    private String manufacturerName;
    private String drugName;
}
