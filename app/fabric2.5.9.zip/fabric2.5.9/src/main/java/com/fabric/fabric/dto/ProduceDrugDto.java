package com.fabric.fabric.dto;

import lombok.Data;

@Data
public class ProduceDrugDto {
    private String manufacturerName;
    private String drugName;
    private String price;
}
