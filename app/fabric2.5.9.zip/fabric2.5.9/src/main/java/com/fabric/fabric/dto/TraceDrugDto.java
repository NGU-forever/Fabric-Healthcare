package com.fabric.fabric.dto;

import lombok.Data;

@Data
public class TraceDrugDto {
    private String traceCode;
}
