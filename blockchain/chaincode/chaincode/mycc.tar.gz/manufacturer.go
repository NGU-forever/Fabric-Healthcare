/*
SPDX-License-Identifier: Apache-2.0
*/

package main

import (
	"encoding/json"
	"fmt"
	"sync"

	"github.com/hyperledger/fabric-contract-api-go/contractapi"
)

// ManufacturerDrug 表示厂家生产的药品信息
type ManufacturerDrug struct {
	Name           string
	TraceCode      string
	Price          float64
	ProductionTime string
	InStock        bool
}

// Manufacturer 表示厂家信息
type Manufacturer struct {
	Name      string
	Contact   string
	Inventory map[string]ManufacturerDrug
	mu        sync.Mutex
}

// ManufacturerContract 定义了厂家合约
type ManufacturerContract struct {
	contractapi.Contract
}

// 全局变量，存储所有厂商信息
var manufacturers = map[string]*Manufacturer{}

// CreateManufacturer 创建一个新的厂家
func (mc *ManufacturerContract) CreateManufacturer(ctx contractapi.TransactionContextInterface, name, contact string) error {
	clientMSPID, err := ctx.GetClientIdentity().GetMSPID()
	if err != nil {
		return fmt.Errorf("failed to get MSPID: %v", err)
	}
	if clientMSPID != "Org3MSP" {
		return fmt.Errorf("unauthorized: only Org3MSP can create a manufacturer")
	}

	manufacturer := &Manufacturer{
		Name:      name,
		Contact:   contact,
		Inventory: make(map[string]ManufacturerDrug),
	}

	manufacturers[name] = manufacturer
	manufacturerJSON, err := json.Marshal(manufacturer)
	if err != nil {
		return err
	}

	return ctx.GetStub().PutState(name, manufacturerJSON)
}

// ProduceDrug 生产药品
func (mc *ManufacturerContract) ProduceDrug(ctx contractapi.TransactionContextInterface, manufacturerName, drugName string, price float64, productionTime string) (string, error) {
	clientMSPID, err := ctx.GetClientIdentity().GetMSPID()
	if err != nil {
		return "", fmt.Errorf("failed to get MSPID: %v", err)
	}
	if clientMSPID != "Org3MSP" {
		return "", fmt.Errorf("unauthorized: only Org3MSP can produce drugs")
	}

	manufacturer := manufacturers[manufacturerName]
	manufacturer.mu.Lock()
	defer manufacturer.mu.Unlock()

	traceCode := GenerateTraceCode(drugName, manufacturerName, fmt.Sprintf("%.2f", price), productionTime)
	drug := ManufacturerDrug{
		Name:           drugName,
		TraceCode:      traceCode,
		Price:          price,
		ProductionTime: productionTime,
		InStock:        true,
	}

	manufacturer.Inventory[drugName] = drug
	manufacturerJSON, err := json.Marshal(manufacturer)
	if err != nil {
		return "", err
	}

	if err := ctx.GetStub().PutState(manufacturerName, manufacturerJSON); err != nil {
		return "", err
	}

	return traceCode, nil
}

// TraceDrug 根据溯源码追踪药品
func (mc *ManufacturerContract) TraceDrug(ctx contractapi.TransactionContextInterface, traceCode string) (DrugInfo, error) {
	drugName, manufacturerName, price, productionTime, err := DecodeTraceCode(traceCode)
	if err != nil {
		return DrugInfo{}, err
	}

	manufacturer := manufacturers[manufacturerName]
	if manufacturer == nil {
		return DrugInfo{}, fmt.Errorf("manufacturer not found")
	}

	drug, exists := manufacturer.Inventory[drugName]
	if !exists {
		return DrugInfo{}, fmt.Errorf("drug not found in manufacturer's inventory")
	}

	return DrugInfo{
		Name:           drug.Name,
		TraceCode:      drug.TraceCode,
		Manufacturer:   manufacturerName,
		Price:          drug.Price,
		ProductionTime: drug.ProductionTime,
		InStock:        drug.InStock,
		HospitalName:   "",
	}, nil
}
